export type TransactionStatus = 'Approved' | 'Flagged' | 'Action Required' | 'Rejected';

export interface AdvancedFraudSignals {
  pattern: 'Cumulative High Value' | 'High Frequency' | 'Beneficiary Concentration' | 'Coordinated Activity' | 'Account Takeover' | 'Impossible Travel' | 'Card Testing Attack';
  cumulativeAmount?: {
    value: number;
    window: '24h' | '7d';
  };
  transactionFrequency?: {
    count: number;
    window: '24h' | '7d';
  };
  beneficiaryConcentration?: {
    fromAccounts: number;
    timeWindow: '1h' | '24h';
  };
  accountTakeoverDetails?: {
    newDevice: string;
    newLocation: string;
    failedLogins: number;
  };
  impossibleTravelDetails?: {
    locations: [string, string];
    times: [string, string];
  };
  cardTestingDetails?: {
    failedAttempts: number;
    timeWindow: '5m' | '1h';
  };
}

export interface Transaction {
  id: string;
  amount: number;
  currency: string;
  merchant: string;
  beneficiaryAccount?: string;
  location: string;
  device: 'Mobile' | 'Desktop' | 'Tablet';
  sharedIdentifiers?: {
    ip?: string;
    deviceId?: string;
  };
  timestamp: string;
  status: TransactionStatus;
  explanation: string;
  authenticationRequired?: 'OTP' | 'KYC';
  customerProfile?: {
    avgTransactionAmount: number;
    typicalLocations: string[];
  };
  advancedFraudSignals?: AdvancedFraudSignals;
}

export interface Metric {
  label: string;
  value: string;
  description: string;
}
