import React from 'react';
import { InfoIcon } from './icons';

interface HeaderProps {
    isAutoVerificationOn: boolean;
    onToggle: () => void;
}

const Header: React.FC<HeaderProps> = ({ isAutoVerificationOn, onToggle }) => {
  return (
    <header className="p-4 border-b border-gray-700 flex justify-between items-center flex-wrap gap-4">
      <h1 className="text-xl lg:text-2xl font-bold text-white tracking-wider">AI Model for Flagging Suspicious Transactions</h1>
      <div className="flex items-center space-x-3">
         <div className="group relative flex items-center">
            <InfoIcon className="h-5 w-5 text-gray-400 mr-2 cursor-pointer" />
            <div className="absolute bottom-full right-0 mb-2 w-64 bg-gray-900 text-white text-xs rounded py-2 px-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10 border border-gray-600">
              <span className="font-bold">Auto-Verification Mode:</span>
              <br />
              <span className="font-bold text-green-400">ON:</span> Automatically approves or rejects transactions needing review.
              <br />
              <span className="font-bold text-red-400">OFF:</span> Requires manual review for 'Action Required' transactions.
            </div>
        </div>
        <span className="text-sm font-medium text-gray-300">Auto-Verification</span>
        <label htmlFor="auto-verify-toggle" className="relative inline-flex items-center cursor-pointer">
          <input 
            type="checkbox" 
            id="auto-verify-toggle" 
            className="sr-only peer"
            checked={isAutoVerificationOn}
            onChange={onToggle}
          />
          <div className="w-11 h-6 bg-gray-600 rounded-full peer peer-focus:ring-2 peer-focus:ring-blue-500 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
        </label>
      </div>
    </header>
  );
};

export default Header;