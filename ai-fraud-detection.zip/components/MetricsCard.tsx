
import React from 'react';
import { InfoIcon } from './icons';
import { Metric } from '../types';

interface MetricsCardProps {
  metric: Metric;
}

const MetricsCard: React.FC<MetricsCardProps> = ({ metric }) => {
  return (
    <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 flex flex-col justify-between">
      <div>
        <div className="flex justify-between items-center">
          <h3 className="text-sm font-medium text-gray-400">{metric.label}</h3>
          <div className="group relative">
            <InfoIcon className="h-4 w-4 text-gray-500 cursor-pointer" />
            <div className="absolute bottom-full mb-2 w-48 bg-gray-900 text-white text-xs rounded py-2 px-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10 border border-gray-600">
              {metric.description}
            </div>
          </div>
        </div>
        <p className="text-3xl font-semibold text-white mt-1">{metric.value}</p>
      </div>
    </div>
  );
};

export default MetricsCard;
