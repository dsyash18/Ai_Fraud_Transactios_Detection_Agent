import React from 'react';
import { Transaction } from '../types';
import { AlertIcon, CheckIcon, DesktopIcon, MobileIcon, TabletIcon, ActionIcon, RejectIcon } from './icons';

interface TransactionItemProps {
  transaction: Transaction;
  isSelected: boolean;
  onSelect: (transaction: Transaction) => void;
}

const DeviceIcon = ({ device }: { device: 'Mobile' | 'Desktop' | 'Tablet' }) => {
  const className = "h-5 w-5 text-gray-400";
  switch (device) {
    case 'Mobile':
      return <MobileIcon className={className} />;
    case 'Desktop':
      return <DesktopIcon className={className} />;
    case 'Tablet':
      return <TabletIcon className={className} />;
    default:
      return null;
  }
};

const StatusIconAndColor = ({ status }: { status: Transaction['status'] }) => {
  switch (status) {
    case 'Approved':
      return { Icon: CheckIcon, color: 'text-green-500', borderColor: 'border-green-500', selectedBorderColor: 'border-green-400', amountColor: 'text-green-400' };
    case 'Flagged':
      return { Icon: AlertIcon, color: 'text-red-500', borderColor: 'border-red-500', selectedBorderColor: 'border-red-400', amountColor: 'text-red-400' };
    case 'Action Required':
      return { Icon: ActionIcon, color: 'text-yellow-500', borderColor: 'border-yellow-500', selectedBorderColor: 'border-yellow-400', amountColor: 'text-yellow-400' };
    case 'Rejected':
      return { Icon: RejectIcon, color: 'text-gray-500', borderColor: 'border-gray-600', selectedBorderColor: 'border-gray-500', amountColor: 'text-gray-500' };
    default:
      return { Icon: CheckIcon, color: 'text-gray-500', borderColor: 'border-gray-700', selectedBorderColor: 'border-gray-600', amountColor: 'text-gray-400' };
  }
};


const TransactionItem: React.FC<TransactionItemProps> = ({ transaction, isSelected, onSelect }) => {
  const { status, amount, currency, merchant, timestamp } = transaction;

  const { Icon, color, borderColor, selectedBorderColor, amountColor } = StatusIconAndColor({ status });

  const baseClasses = "flex items-center p-3 cursor-pointer transition-colors duration-200 ease-in-out border-l-4";
  const selectedClasses = "bg-gray-700/50";
  const unselectedClasses = "hover:bg-gray-800/60";
  
  const finalClasses = `${baseClasses} ${isSelected ? selectedClasses : unselectedClasses} ${isSelected ? selectedBorderColor : borderColor}`;

  return (
    <li className={finalClasses} onClick={() => onSelect(transaction)}>
      <div className="flex-shrink-0 mr-4">
        <Icon className={`h-6 w-6 ${color}`} />
      </div>
      <div className="flex-grow">
        <p className="font-semibold text-white">{merchant}</p>
        <p className="text-sm text-gray-400">{new Date(timestamp).toLocaleString()}</p>
      </div>
      <div className="flex items-center text-right">
        <div className="mr-4">
            <p className={`font-bold text-lg ${amountColor}`}>
            {new Intl.NumberFormat('en-US', { style: 'currency', currency: currency || 'USD' }).format(amount)}
            </p>
        </div>
        <DeviceIcon device={transaction.device} />
      </div>
    </li>
  );
};

export default TransactionItem;