import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { generateTransactions } from '../services/geminiService';
import { Transaction, Metric, TransactionStatus } from '../types';
import Header from './Header';
import MetricsCard from './MetricsCard';
import TransactionFeed, { FilterStatus } from './TransactionFeed';
import AnalysisPanel from './AnalysisPanel';

const Dashboard: React.FC = () => {
  const [allTransactions, setAllTransactions] = useState<Transaction[]>([]);
  const [displayedTransactions, setDisplayedTransactions] = useState<Transaction[]>([]);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<FilterStatus>('all');
  const [nextTransactionIndex, setNextTransactionIndex] = useState(0);
  const [isAutoVerificationOn, setIsAutoVerificationOn] = useState(true);

  const handleAutoVerificationToggle = () => setIsAutoVerificationOn(prev => !prev);

  const initialFetchTransactions = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const transactions = await generateTransactions();
      if (transactions.length > 0) {
        setAllTransactions(transactions);
        setDisplayedTransactions([]);
        setSelectedTransaction(transactions[0]);
        setNextTransactionIndex(0);
      } else {
        setError("No transactions were generated.");
      }
    } catch (err) {
      setError("Failed to fetch transaction data.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const appendNewTransactions = useCallback(async () => {
    try {
      const newTransactions = await generateTransactions();
      if (newTransactions.length > 0) {
        setAllTransactions(prevAll => {
          const existingIds = new Set(prevAll.map(t => t.id));
          const uniqueNew = newTransactions.filter(t => !existingIds.has(t.id));
          return [...prevAll, ...uniqueNew];
        });
      }
    } catch (err) {
      console.error("Failed to fetch additional transactions:", err);
    }
  }, []);

  useEffect(() => {
    initialFetchTransactions();
  }, [initialFetchTransactions]);

  useEffect(() => {
    if (isLoading) return; 

    const refetchInterval = setInterval(() => {
      appendNewTransactions();
    }, 120000); 

    return () => clearInterval(refetchInterval);
  }, [isLoading, appendNewTransactions]);

  useEffect(() => {
    if (isLoading || nextTransactionIndex >= allTransactions.length) {
      return;
    }

    const displayInterval = setInterval(() => {
      let nextTransaction = { ...allTransactions[nextTransactionIndex] };

      if (nextTransaction.status === 'Action Required' && isAutoVerificationOn) {
        // Simulate AI confidence and auto-process
        const confidenceScore = Math.random();
        const newStatus = confidenceScore > 0.3 ? 'Approved' : 'Rejected'; // 70% chance to approve
        nextTransaction.status = newStatus;
        
        // Update the master list so the state is consistent
        setAllTransactions(prevAll => 
            prevAll.map((t, index) => index === nextTransactionIndex ? nextTransaction : t)
        );
      }

      setDisplayedTransactions(prev => [nextTransaction, ...prev]);
      setNextTransactionIndex(prevIndex => prevIndex + 1);
    }, 800);

    return () => clearInterval(displayInterval);
  }, [allTransactions, nextTransactionIndex, isLoading, isAutoVerificationOn]);

  const handleTransactionAction = (transactionId: string, newStatus: 'Approved' | 'Rejected') => {
    const updateTransactionStatus = (transactions: Transaction[]) => 
      transactions.map(t => t.id === transactionId ? { ...t, status: newStatus } : t);
    
    setAllTransactions(updateTransactionStatus);
    setDisplayedTransactions(updateTransactionStatus);

    // Also update the selected transaction if it's the one being actioned
    if (selectedTransaction?.id === transactionId) {
        setSelectedTransaction(prev => prev ? { ...prev, status: newStatus } : null);
    }
  };

  const metrics: Metric[] = useMemo(() => {
    const total = displayedTransactions.length;
    const flagged = displayedTransactions.filter(t => t.status === 'Flagged' || t.status === 'Action Required').length;
    // These are simulated metrics for demonstration
    const precision = total > 0 && flagged > 0 ? ((flagged * 0.92) / flagged).toFixed(2) : '0.00'; // Assume 92% are actual fraud
    const recall = total > 0 ? '95.7%' : '0.0%';
    
    return [
      { label: 'Total Transactions', value: total.toString(), description: 'Total number of transactions processed in the current view.' },
      { label: 'Suspicious Flags', value: flagged.toString(), description: 'Transactions flagged as potentially fraudulent by the AI model.' },
      { label: 'Precision', value: `${(parseFloat(precision) * 100).toFixed(0)}%`, description: 'Of all flagged transactions, this percentage were actual fraud.' },
      { label: 'Recall', value: recall, description: 'Percentage of all actual fraud transactions that were successfully caught by the model.' },
    ];
  }, [displayedTransactions]);

  const filteredTransactions = useMemo(() => {
    switch(filterStatus) {
        case 'all':
            return displayedTransactions;
        case 'suspicious':
            return displayedTransactions.filter(t => t.status === 'Flagged' || t.status === 'Rejected');
        case 'normal':
            return displayedTransactions.filter(t => t.status === 'Approved');
        case 'action_required':
            return displayedTransactions.filter(t => t.status === 'Action Required');
        default:
            return displayedTransactions;
    }
  }, [displayedTransactions, filterStatus]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
            <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-blue-500 mx-auto"></div>
            <p className="mt-4 text-lg text-gray-400">Initializing AI Model & Generating Data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return <div className="flex items-center justify-center h-screen text-red-500">{error}</div>;
  }

  return (
    <div className="flex flex-col h-screen">
      <Header isAutoVerificationOn={isAutoVerificationOn} onToggle={handleAutoVerificationToggle} />
      <main className="flex-grow p-4 lg:p-6 space-y-4 lg:space-y-6 flex flex-col">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {metrics.map(metric => <MetricsCard key={metric.label} metric={metric} />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 flex-grow min-h-0">
          <div className="lg:col-span-1 min-h-[400px] lg:min-h-0">
            <TransactionFeed
              transactions={filteredTransactions}
              selectedTransaction={selectedTransaction}
              onSelectTransaction={setSelectedTransaction}
              filterStatus={filterStatus}
              onFilterChange={setFilterStatus}
              hasTransactions={displayedTransactions.length > 0}
            />
          </div>
           <div className="lg:col-span-1 min-h-[400px] lg:min-h-0">
             <AnalysisPanel transaction={selectedTransaction} onAction={handleTransactionAction} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;