import React, { useState, useRef } from 'react';
import { Transaction } from '../types';
import TransactionItem from './TransactionItem';

export type FilterStatus = 'all' | 'suspicious' | 'normal' | 'action_required';

interface TransactionFeedProps {
  transactions: Transaction[];
  selectedTransaction: Transaction | null;
  onSelectTransaction: (transaction: Transaction) => void;
  filterStatus: FilterStatus;
  onFilterChange: (status: FilterStatus) => void;
  hasTransactions: boolean;
}

// Constants for virtualization
const ITEM_HEIGHT = 76; // Estimated height in pixels for one item (68px for item + 8px for spacing)
const OVERSCAN_COUNT = 10; // Render items above and below the viewport for smoother scrolling

const FilterButton: React.FC<{
  label: string;
  status: FilterStatus;
  currentStatus: FilterStatus;
  onClick: (status: FilterStatus) => void;
}> = ({ label, status, currentStatus, onClick }) => {
  const isActive = status === currentStatus;
  const baseClasses = "px-3 py-1 text-xs font-medium rounded-md transition-colors duration-200";
  const activeClasses = "bg-blue-600 text-white";
  const inactiveClasses = "bg-gray-700 text-gray-300 hover:bg-gray-600";

  return (
    <button
      className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
      onClick={() => onClick(status)}
      aria-pressed={isActive}
    >
      {label}
    </button>
  );
};

const TransactionFeed: React.FC<TransactionFeedProps> = ({ transactions, selectedTransaction, onSelectTransaction, filterStatus, onFilterChange, hasTransactions }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
  };
  
  const renderContent = () => {
    if (transactions.length > 0) {
      const containerHeight = scrollContainerRef.current?.clientHeight || window.innerHeight;
      const totalHeight = transactions.length * ITEM_HEIGHT;

      const startIndex = Math.max(0, Math.floor(scrollTop / ITEM_HEIGHT) - OVERSCAN_COUNT);
      const endIndex = Math.min(transactions.length, Math.ceil((scrollTop + containerHeight) / ITEM_HEIGHT) + OVERSCAN_COUNT);

      const visibleTransactions = transactions.slice(startIndex, endIndex);

      return (
        <div
          ref={scrollContainerRef}
          className="overflow-y-auto flex-grow"
          onScroll={handleScroll}
        >
          <ul
            id="transaction-feed-list"
            className="relative"
            style={{ height: `${totalHeight}px` }}
          >
            {visibleTransactions.map((tx, i) => {
              const index = startIndex + i;
              return (
                <li
                  key={tx.id}
                  className="absolute"
                  style={{
                    top: `${index * ITEM_HEIGHT}px`,
                    height: `${ITEM_HEIGHT}px`,
                    left: '8px',
                    right: '8px',
                    paddingBottom: '8px',
                  }}
                >
                  <TransactionItem
                    transaction={tx}
                    isSelected={selectedTransaction?.id === tx.id}
                    onSelect={onSelectTransaction}
                  />
                </li>
              );
            })}
          </ul>
        </div>
      );
    }

    let message: string;
    if (!hasTransactions) {
        message = "Waiting for transactions...";
    } else if (filterStatus === 'suspicious') {
        message = "No suspicious transactions match the filter.";
    } else if (filterStatus === 'normal') {
        message = "No approved transactions match the filter.";
    } else if (filterStatus === 'action_required') {
        message = "No transactions require action.";
    } else {
        message = "No transactions to display.";
    }

    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-gray-500">{message}</p>
      </div>
    );
  };
  
  return (
    <div className="bg-gray-800/50 rounded-lg border border-gray-700 h-full flex flex-col">
       <div className="p-4 border-b border-gray-700 flex justify-between items-center flex-wrap gap-2">
            <h2 className="text-lg font-semibold text-white">Live Transaction Feed</h2>
            <div className="flex items-center space-x-2 flex-wrap">
                <FilterButton label="All" status="all" currentStatus={filterStatus} onClick={onFilterChange} />
                <FilterButton label="Suspicious" status="suspicious" currentStatus={filterStatus} onClick={onFilterChange} />
                <FilterButton label="Approved" status="normal" currentStatus={filterStatus} onClick={onFilterChange} />
                <FilterButton label="Action Required" status="action_required" currentStatus={filterStatus} onClick={onFilterChange} />
            </div>
        </div>
      {renderContent()}
    </div>
  );
};

export default TransactionFeed;