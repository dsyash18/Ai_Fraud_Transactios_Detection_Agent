import React from 'react';
import { Transaction, AdvancedFraudSignals } from '../types';
import { AlertIcon, CheckIcon, DollarIcon, LocationIcon, InfoIcon, ActionIcon, RejectIcon } from './icons';

interface AnalysisPanelProps {
  transaction: Transaction | null;
  onAction?: (transactionId: string, newStatus: 'Approved' | 'Rejected') => void;
}

const DetailItem: React.FC<{ icon: React.ReactNode; label: string; value: string | React.ReactNode;}> = ({ icon, label, value }) => (
  <div className="flex items-start py-3">
    <div className="flex-shrink-0 w-6 h-6 mr-4 text-gray-400">{icon}</div>
    <div>
      <p className="text-sm text-gray-400">{label}</p>
      <p className="font-semibold text-white">{value}</p>
    </div>
  </div>
);

const StatusDisplay: React.FC<{ transaction: Transaction }> = ({ transaction }) => {
    const { status, explanation } = transaction;

    switch (status) {
        case 'Approved':
            return (
                <div className="bg-green-900/30 border border-green-500/50 text-green-300 p-4 rounded-lg mb-6">
                    <div className="flex">
                        <CheckIcon className="h-6 w-6 mr-3 flex-shrink-0" />
                        <div>
                            <h3 className="font-bold">Transaction Approved</h3>
                            <p className="text-sm mt-1">This transaction appears to be legitimate.</p>
                        </div>
                    </div>
                </div>
            );
        case 'Flagged':
            return (
                <div className="bg-red-900/30 border border-red-500/50 text-red-300 p-4 rounded-lg mb-6">
                    <div className="flex">
                        <AlertIcon className="h-6 w-6 mr-3 flex-shrink-0" />
                        <div>
                            <h3 className="font-bold">Suspicious Activity Flagged</h3>
                            <p className="text-sm mt-1">{explanation}</p>
                        </div>
                    </div>
                </div>
            );
        case 'Action Required':
             return (
                <div className="bg-yellow-900/30 border border-yellow-500/50 text-yellow-300 p-4 rounded-lg mb-6">
                    <div className="flex">
                        <ActionIcon className="h-6 w-6 mr-3 flex-shrink-0" />
                        <div>
                            <h3 className="font-bold">Action Required</h3>
                            <p className="text-sm mt-1">{explanation}</p>
                        </div>
                    </div>
                </div>
            );
        case 'Rejected':
            return (
                <div className="bg-gray-700/30 border border-gray-600/50 text-gray-400 p-4 rounded-lg mb-6">
                    <div className="flex">
                        <RejectIcon className="h-6 w-6 mr-3 flex-shrink-0" />
                        <div>
                            <h3 className="font-bold">Transaction Rejected</h3>
                            <p className="text-sm mt-1">This transaction was manually rejected.</p>
                        </div>
                    </div>
                </div>
            );
        default:
            return null;
    }
}

const AdvancedSignalsDisplay: React.FC<{ signals: AdvancedFraudSignals, currency: string }> = ({ signals, currency }) => {
    const { pattern, cumulativeAmount, transactionFrequency, beneficiaryConcentration, accountTakeoverDetails, impossibleTravelDetails, cardTestingDetails } = signals;

    const renderDetails = () => {
        switch (pattern) {
            case 'Cumulative High Value':
                if (cumulativeAmount) {
                    return <DetailItem icon={<InfoIcon />} label="Details" value={`Total of ${new Intl.NumberFormat('en-US', { style: 'currency', currency: currency || 'USD' }).format(cumulativeAmount.value)} transferred in the last ${cumulativeAmount.window}.`} />;
                }
                return null;
            case 'High Frequency':
                if (transactionFrequency) {
                    return <DetailItem icon={<InfoIcon />} label="Details" value={`A total of ${transactionFrequency.count} transactions were made in the last ${transactionFrequency.window}.`} />;
                }
                return null;
            case 'Beneficiary Concentration':
                 if (beneficiaryConcentration) {
                    return <DetailItem icon={<InfoIcon />} label="Details" value={`Beneficiary received funds from ${beneficiaryConcentration.fromAccounts} different accounts in the last ${beneficiaryConcentration.timeWindow}.`} />;
                }
                return null;
            case 'Account Takeover':
                if (accountTakeoverDetails) {
                    return (
                        <>
                            <DetailItem icon={<InfoIcon />} label="Suspicious Device" value={accountTakeoverDetails.newDevice} />
                            <DetailItem icon={<InfoIcon />} label="Suspicious Location" value={accountTakeoverDetails.newLocation} />
                            <DetailItem icon={<InfoIcon />} label="Failed Logins" value={`${accountTakeoverDetails.failedLogins} prior to this transaction.`} />
                        </>
                    );
                }
                return null;
            case 'Impossible Travel':
                 if (impossibleTravelDetails) {
                    const [loc1, loc2] = impossibleTravelDetails.locations;
                    const [time1, time2] = impossibleTravelDetails.times;
                    const timeDiff = Math.abs(new Date(time2).getTime() - new Date(time1).getTime()) / (1000 * 60);
                    return <DetailItem icon={<InfoIcon />} label="Conflicting Transactions" value={`Card used in ${loc1} and ${loc2} within ${timeDiff.toFixed(0)} minutes.`} />;
                }
                return null;
            case 'Card Testing Attack':
                 if (cardTestingDetails) {
                    return <DetailItem icon={<InfoIcon />} label="Attack Details" value={`${cardTestingDetails.failedAttempts} failed attempts detected in the last ${cardTestingDetails.timeWindow} before this transaction.`} />;
                }
                return null;
            default:
                return null;
        }
    };

    return (
        <div className="mt-6">
            <h4 className="text-md font-semibold text-gray-300 border-b border-gray-700 pb-2 mb-2">Advanced Fraud Pattern Analysis</h4>
            <DetailItem icon={<InfoIcon />} label="Pattern Detected" value={<span className="font-bold text-yellow-400">{pattern}</span>} />
            {renderDetails()}
        </div>
    );
};


const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ transaction, onAction }) => {
  if (!transaction) {
    return (
      <div className="bg-gray-800/50 rounded-lg border border-gray-700 h-full flex items-center justify-center">
        <p className="text-gray-500">Select a transaction to see details</p>
      </div>
    );
  }

  const { currency, amount, merchant, location, device, timestamp, customerProfile, status, authenticationRequired, beneficiaryAccount, sharedIdentifiers, advancedFraudSignals } = transaction;

  return (
    <div className="bg-gray-800/50 rounded-lg border border-gray-700 h-full flex flex-col">
       <div className="p-4 border-b border-gray-700">
            <h2 className="text-lg font-semibold text-white">Transaction Analysis</h2>
        </div>

      <div className="p-6 overflow-y-auto flex-grow">
        <StatusDisplay transaction={transaction} />

        {status === 'Action Required' && onAction && (
          <div className="grid grid-cols-2 gap-4 mb-6">
            <button
              onClick={() => onAction(transaction.id, 'Approved')}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition-colors duration-200"
            >
              Approve
            </button>
            <button
              onClick={() => onAction(transaction.id, 'Rejected')}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition-colors duration-200"
            >
              Reject
            </button>
          </div>
        )}

        <div className="space-y-2">
            <h4 className="text-md font-semibold text-gray-300 border-b border-gray-700 pb-2 mb-2">Transaction Details</h4>
            <DetailItem icon={<DollarIcon />} label="Amount" value={`${new Intl.NumberFormat('en-US', { style: 'currency', currency: currency || 'USD' }).format(amount)}`} />
            <DetailItem icon={<LocationIcon />} label="Merchant & Location" value={`${merchant}, ${location}`} />
            {beneficiaryAccount && <DetailItem icon={<InfoIcon />} label="Beneficiary Account" value={beneficiaryAccount} />}
            {authenticationRequired && <DetailItem icon={<InfoIcon />} label="Verification" value={`Requires ${authenticationRequired}`} />}
            <DetailItem icon={<InfoIcon />} label="Device" value={device} />
            {sharedIdentifiers?.ip && <DetailItem icon={<InfoIcon />} label="Origin IP Address" value={sharedIdentifiers.ip} />}
            <DetailItem icon={<InfoIcon />} label="Date & Time" value={new Date(timestamp).toLocaleString()} />
        </div>
        
        {advancedFraudSignals && <AdvancedSignalsDisplay signals={advancedFraudSignals} currency={currency} />}

        <div className="mt-6">
            <h4 className="text-md font-semibold text-gray-300 border-b border-gray-700 pb-2 mb-2">Customer Profile Context</h4>
            {customerProfile ? (
                <>
                    <DetailItem 
                        icon={<DollarIcon />} 
                        label="Average Transaction" 
                        value={typeof customerProfile.avgTransactionAmount === 'number' 
                                ? new Intl.NumberFormat('en-US', { style: 'currency', currency: currency || 'USD' }).format(customerProfile.avgTransactionAmount)
                                : 'N/A'}
                    />
                    <DetailItem 
                        icon={<LocationIcon />} 
                        label="Typical Locations" 
                        value={customerProfile.typicalLocations?.join(', ') || 'N/A'} 
                    />
                </>
            ) : <p className="text-sm text-gray-500 italic">No customer profile data available (new user).</p>}
        </div>
      </div>
    </div>
  );
};

export default AnalysisPanel;
