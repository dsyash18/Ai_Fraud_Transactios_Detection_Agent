import { GoogleGenAI, Type } from "@google/genai";
import { Transaction } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const generateTransactions = async (): Promise<Transaction[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate a list of 25 realistic financial transactions, incorporating a wide range of basic and advanced fraud detection scenarios.

      **Fraud Detection Logic to Simulate (Include at least one of each):**

      1.  **Account Takeover (ATO):**
          *   Create a 'Flagged' transaction originating from an unusual device and location for an existing customer.
          *   The 'explanation' must be: "Transaction initiated from a new device and location following multiple failed login attempts, indicating a potential account takeover."
          *   Populate 'advancedFraudSignals' with: { pattern: 'Account Takeover', accountTakeoverDetails: { newDevice: 'Unknown Android Device', newLocation: 'Bucharest, Romania', failedLogins: 8 } }.

      2.  **Impossible Travel:**
          *   Create a 'Flagged' transaction that is geographically impossible given the user's previous transaction.
          *   The 'explanation' must be: "Impossible travel detected. The card was used in two distant locations within an impossible timeframe."
          *   Populate 'advancedFraudSignals' with: { pattern: 'Impossible Travel', impossibleTravelDetails: { locations: ['New York, USA', 'Tokyo, Japan'], times: ['2024-08-15T14:00:00Z', '2024-08-15T14:20:00Z'] } }.

      3.  **Card Testing Attack:**
          *   Create a small-value 'Flagged' transaction ($0.50 to $2.00).
          *   The 'explanation' must be: "This transaction is part of a high-frequency burst of small-value attempts, indicative of a card testing attack."
          *   Populate 'advancedFraudSignals' with: { pattern: 'Card Testing Attack', cardTestingDetails: { failedAttempts: 32, timeWindow: '5m' } }.

      4.  **Coordinated Fraud (Entity Linking):**
          *   Create a cluster of 2-3 'Flagged' transactions from new accounts sharing an IP, targeting the same beneficiary.
          *   The 'explanation' must be: "Flagged due to coordinated transfers from multiple new accounts sharing an IP to a single beneficiary."

      5.  **New User Risk (Action Required):**
          *   Generate 1-2 'Action Required' transactions for new users making large first-time purchases, requiring 'KYC' or 'OTP'.

      6.  **Cumulative & Frequency-Based Fraud:**
          *   Generate 1-2 'Flagged' transactions caught by cumulative or frequency rules (e.g., 'Cumulative High Value', 'High Frequency', 'Beneficiary Concentration'). Provide the corresponding 'advancedFraudSignals' object.

      7.  **Standard Suspicious Activity (Existing Users):**
          *   Generate 2-3 'Flagged' transactions based on deviations from a 'customerProfile'.

      8.  **Normal Activity (Approved):**
          *   The remaining transactions should be 'Approved' with an empty 'explanation' string.

      For each transaction, provide all fields. Ensure the output is a valid JSON array and all string values are properly escaped.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              amount: { type: Type.NUMBER },
              currency: { type: Type.STRING },
              merchant: { type: Type.STRING },
              beneficiaryAccount: { type: Type.STRING, nullable: true },
              location: { type: Type.STRING },
              device: { type: Type.STRING },
              sharedIdentifiers: {
                type: Type.OBJECT,
                nullable: true,
                properties: {
                  ip: { type: Type.STRING },
                  deviceId: { type: Type.STRING },
                },
              },
              timestamp: { type: Type.STRING },
              status: { type: Type.STRING },
              explanation: { type: Type.STRING },
              authenticationRequired: { type: Type.STRING, nullable: true },
              customerProfile: {
                type: Type.OBJECT,
                nullable: true,
                properties: {
                  avgTransactionAmount: { type: Type.NUMBER },
                  typicalLocations: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                },
              },
              advancedFraudSignals: {
                type: Type.OBJECT,
                nullable: true,
                properties: {
                  pattern: { type: Type.STRING },
                  cumulativeAmount: {
                    type: Type.OBJECT, nullable: true,
                    properties: { value: { type: Type.NUMBER }, window: { type: Type.STRING } }
                  },
                  transactionFrequency: {
                    type: Type.OBJECT, nullable: true,
                    properties: { count: { type: Type.NUMBER }, window: { type: Type.STRING } }
                  },
                  beneficiaryConcentration: {
                    type: Type.OBJECT, nullable: true,
                    properties: { fromAccounts: { type: Type.NUMBER }, timeWindow: { type: Type.STRING } }
                  },
                  accountTakeoverDetails: {
                    type: Type.OBJECT, nullable: true,
                    properties: { newDevice: { type: Type.STRING }, newLocation: { type: Type.STRING }, failedLogins: { type: Type.NUMBER } }
                  },
                  impossibleTravelDetails: {
                    type: Type.OBJECT, nullable: true,
                    properties: { 
                      locations: { type: Type.ARRAY, items: { type: Type.STRING } },
                      times: { type: Type.ARRAY, items: { type: Type.STRING } }
                    }
                  },
                  cardTestingDetails: {
                    type: Type.OBJECT, nullable: true,
                    properties: { failedAttempts: { type: Type.NUMBER }, timeWindow: { type: Type.STRING } }
                  }
                }
              }
            },
          },
        },
      },
    });

    let jsonText = response.text.trim();
    if (jsonText.startsWith('```json')) {
      jsonText = jsonText.substring(7, jsonText.length - 3).trim();
    } else if (jsonText.startsWith('```')) {
      jsonText = jsonText.substring(3, jsonText.length - 3).trim();
    }

    const transactions = JSON.parse(jsonText);
    return transactions;
  } catch (error) {
    console.error("Error generating transactions:", error);
    // In case of an API error, return some mock data to keep the app functional.
    return [
        {
            id: 'mock-1',
            amount: 5500.00,
            currency: 'USD',
            merchant: 'Luxury Goods Inc.',
            location: 'Monaco, Monaco',
            device: 'Desktop',
            timestamp: new Date().toISOString(),
            status: 'Action Required',
            authenticationRequired: 'KYC',
            explanation: 'API Error: This is mock data. Large first-time transaction from a new user in a high-risk location requires KYC verification.',
        },
        {
            id: 'mock-2',
            amount: 45.50,
            currency: 'USD',
            merchant: 'Corner Cafe',
            location: 'New York, USA',
            device: 'Mobile',
            timestamp: new Date().toISOString(),
            status: 'Approved',
            explanation: '',
            customerProfile: { avgTransactionAmount: 50, typicalLocations: ['New York, USA', 'London, UK'] }
        }
    ];
  }
};
